<?php $__env->startSection('title', 'RuangLab'); ?>
<?php $__env->startSection('content-prefix', 'Daftar Layanan Jasa'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Daftar Layanan Jasa'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h4>
                            <b>
                                Daftar Layanan Jasa
                            </b>
                        </h4>
                    </div>

                    <?php if($users->login_level == 'admin'): ?>
                        <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                            <button type="button" class="btn btn-sm btn-info d-flex justify-content-end" data-toggle="modal"
                                data-target="#modal_tambah">Tambah Layanan Jasa</button>
                        </div>
                    <?php endif; ?>

                    <!-- Modal Tambah -->
                    <div class="modal fade" id="modal_tambah" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabelLogout">
                                        Peringatan Aksi!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <form action="<?php echo e(route('tambah-jasa')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="container">

                                            <div class="form-row">
                                                <div class="form-group col-sm-12 col-md-12 col-lg-12">
                                                    <label for="jasa_nama_alat">
                                                        Nama Alat
                                                    </label>
                                                    <input type="text" class="form-control" id="jasa_nama_alat"
                                                        name="jasa_nama_alat">
                                                </div>
                                            </div>

                                            <div class="form-row">
                                                <div class="form-group col-sm-12 col-md-12 col-lg-12">
                                                    <label for="jasa_harga_care">Jumlah
                                                        Stok</label>
                                                    <input type="number" class="form-control" id="jasa_harga_care"
                                                        name="jasa_harga_care">
                                                </div>
                                            </div>

                                            <div class="form-row">
                                                <div class="form-group col-sm-12 col-md-12 col-lg-12">
                                                    <label for="jasa_harga_cleaning">Nilai
                                                        (Harga
                                                        Sewa)
                                                    </label>
                                                    <input type="number" class="form-control" id="jasa_harga_cleaning"
                                                        name="jasa_harga_cleaning">
                                                </div>
                                            </div>

                                            <div class="form-row">
                                                <div class="form-group col-sm-12 col-md-12 col-lg-12">
                                                    <label for="jasa_harga_kalibrasi">Jumlah
                                                        Stok</label>
                                                    <input type="number" class="form-control" id="jasa_harga_kalibrasi"
                                                        name="jasa_harga_kalibrasi">
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-danger"
                                            data-dismiss="modal">Batalkan</button>
                                        <button type="submit" class="btn btn-primary">Ubah
                                            Data</button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                    <!-- END Modal Tambah -->

                </div>

                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Pelayanan</th>
                                    <th>Care (CAR)</th>
                                    <th>Cleaning (CLEAN)</th>
                                    <th>Kalibrasi (CAL)</th>
                                    <th>Tarif Paket Lengkap (CAR + CLEAN + CAL)</th>
                                    <?php if($users->login_level == 'admin'): ?>
                                        <th>Opsi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $jasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center"><?php echo e($item->jasa_nama_alat); ?></td>
                                        <td class="text-center">
                                            <?php echo e('Rp ' . number_format($item->jasa_harga_care, 2, ',', '.')); ?>

                                        </td>
                                        <td class="text-center">
                                            <?php echo e('Rp ' . number_format($item->jasa_harga_cleaning, 2, ',', '.')); ?>

                                        </td>
                                        <td class="text-center">
                                            <?php echo e('Rp ' . number_format($item->jasa_harga_kalibrasi, 2, ',', '.')); ?>

                                        </td>
                                        <td class="">
                                            <?php
                                                $sum_total = $item->jasa_harga_care + $item->jasa_harga_cleaning + $item->jasa_harga_kalibrasi;
                                            ?>
                                            <?php echo e('Rp ' . number_format($sum_total, 2, ',', '.')); ?>

                                        </td>
                                        <?php if($users->login_level == 'admin'): ?>
                                            <td class="mx-auto btn-group">
                                                
                                                <button type="button" class="btn btn-sm btn-info mr-1" data-toggle="modal"
                                                    data-target="#modal_ubah<?php echo e($item->id); ?>">Ubah</button>
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                                    data-target="#modal_hapus<?php echo e($item->id); ?>">Hapus</button>


                                                <!-- Modal Ubah -->
                                                <div class="modal fade" id="modal_ubah<?php echo e($item->id); ?>" tabindex="-1"
                                                    role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                    Peringatan Aksi!</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>

                                                            <form action="<?php echo e(route('ubah-jasa', $item->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-body">

                                                                    <div class="container">

                                                                        <div class="form-row">
                                                                            <div
                                                                                class="form-group col-sm-12 col-md-12 col-lg-12">
                                                                                <label for="jasa_nama_alat">
                                                                                    Nama Alat
                                                                                </label>
                                                                                <input type="text" class="form-control"
                                                                                    id="jasa_nama_alat"
                                                                                    name="jasa_nama_alat"
                                                                                    value="<?php echo e($item->jasa_nama_alat); ?>">
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-row">
                                                                            <div
                                                                                class="form-group col-sm-12 col-md-12 col-lg-12">
                                                                                <label for="jasa_harga_care">Jumlah
                                                                                    Stok</label>
                                                                                <input type="number" class="form-control"
                                                                                    id="jasa_harga_care"
                                                                                    name="jasa_harga_care"
                                                                                    value="<?php echo e($item->jasa_harga_care); ?>">
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-row">
                                                                            <div
                                                                                class="form-group col-sm-12 col-md-12 col-lg-12">
                                                                                <label for="jasa_harga_cleaning">Nilai
                                                                                    (Harga
                                                                                    Sewa)
                                                                                </label>
                                                                                <input type="number" class="form-control"
                                                                                    id="jasa_harga_cleaning"
                                                                                    name="jasa_harga_cleaning"
                                                                                    value="<?php echo e($item->jasa_harga_cleaning); ?>">
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-row">
                                                                            <div
                                                                                class="form-group col-sm-12 col-md-12 col-lg-12">
                                                                                <label for="jasa_harga_kalibrasi">Jumlah
                                                                                    Stok</label>
                                                                                <input type="number" class="form-control"
                                                                                    id="jasa_harga_kalibrasi"
                                                                                    name="jasa_harga_kalibrasi"
                                                                                    value="<?php echo e($item->jasa_harga_kalibrasi); ?>">
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-outline-danger"
                                                                        data-dismiss="modal">Batalkan</button>
                                                                    <button type="submit" class="btn btn-primary">Ubah
                                                                        Data</button>
                                                                </div>

                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END Modal Ubah -->

                                                <!-- Modal Hapus -->
                                                <div class="modal fade" id="modal_hapus<?php echo e($item->id); ?>"
                                                    tabindex="-1" role="dialog"
                                                    aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                    Peringatan
                                                                    Aksi!</h5>
                                                                <button type="button" class="close"
                                                                    data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Apakah anda yakin ingin menghapus item ini?
                                                                    <br>
                                                                    Nama Barang : <b><?php echo e($item->barang_nama); ?></b>
                                                                </p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form action="<?php echo e(route('hapus-jasa', $item->id)); ?>"
                                                                    method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="hapus_id"
                                                                        value="<?php echo e($item->id); ?>">
                                                                    <button type="button" class="btn btn-outline-danger"
                                                                        data-dismiss="modal">Batalkan</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Hapus</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-lab\resources\views/jasa/daftar-jasa.blade.php ENDPATH**/ ?>