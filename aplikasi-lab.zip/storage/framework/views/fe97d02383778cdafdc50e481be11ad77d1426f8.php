<?php $__env->startSection('title', 'RuangLab - Daftar Penawaran'); ?>
<?php $__env->startSection('content-prefix', 'Daftar Penawaran'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Daftar Penawaran'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h4>
                            <b>
                                Daftar Penawaran
                            </b>
                        </h4>
                    </div>

                    <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                        <button type="button" class="badge badge-lg badge-primary mr-1">
                            <b>Total Pilihan :
                                <span id="counterbadges">0</span>
                            </b>
                        </button>
                        <form action="<?php echo e(route('pembuatan-invoice')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="hide_penawaran" id="hide_penawaran">
                            <button type="submit" class="btn btn-md btn-primary">
                                Proses
                            </button>
                        </form>
                    </div>
                </div>

                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Pembuat Penawaran</th>
                                    <th>Nama Barang</th>
                                    <th>Kode Penawaran</th>
                                    <th>Status</th>
                                    <th>Harga Total</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $penawaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->data->data_nama); ?></td>
                                        <td><?php echo e($item->barang->barang_nama); ?></td>
                                        <td><?php echo e($item->penawaran_kode); ?></td>
                                        <td><?php echo e($item->penawaran_status); ?></td>
                                        <td><?php echo e($item->penawaran_harga_total); ?></td>
                                        <td class="mx-auto btn-group">
                                            
                                            
                                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                                data-target="#modal_hapus<?php echo e($item->id); ?>">Hapus</button>
                                            <button type="button" class="btn btn-sm btn-info mr-1"
                                                onclick="simpan_penawaran(<?php echo e($item->id); ?>)">PILIH</button>

                                            <!-- Modal Hapus -->
                                            <div class="modal fade" id="modal_hapus<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">Peringatan
                                                                Aksi!</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Apakah anda yakin ingin menghapus item ini?
                                                                <br>
                                                                Kode Penawaran : <b><?php echo e($item->penawaran_kode); ?></b>
                                                            </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form action="<?php echo e(route('hapus-penawaran', $item->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="hapus_id"
                                                                    value="<?php echo e($item->id); ?>">
                                                                <button type="button" class="btn btn-outline-danger"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Hapus</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        let array_penawaran = [];
        let count_items = 0;
        var counterbadges = document.getElementById("counterbadges");

        function counterUp() {
            count_items++;
            counterbadges.innerHTML = count_items;
            $('#hide_penawaran').val(array_penawaran);
        }

        function simpan_penawaran(id_penawaran) {
            console.log("fungsi simpan id penawaran");
            if (array_penawaran.length !== 0) {
                check_array = array_penawaran.indexOf(id_penawaran);
                if (check_array > -1) {
                    array_penawaran.splice(check_array, -1);
                } else {
                    counterUp();
                    array_penawaran.push(id_penawaran)
                }
            } else {
                counterUp();
                array_penawaran.push(id_penawaran)
            }
            console.log(array_penawaran);
            $('#hide_penawaran').val(array_penawaran);
        }

        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-lab\resources\views/penawaran/daftar-penawaran.blade.php ENDPATH**/ ?>