<?php $__env->startSection('title', 'RuangLab - Buat Penawaran'); ?>
<?php $__env->startSection('content-prefix', 'Buat Penawaran'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Buat Penawaran'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="card mb-4">
        <div class="card-body">
            <div class="container">

                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <p>Silahkan melakukan penawaran dengan memilih satu atau lebih dari barang yang tersedia pada tabel
                            dibawah. Jangan lupa mengisi deskripsi penawaran dan Tekan tombol "Proses Penawaran" jika ingin
                            menyelesaikan penawaran untuk melanjutkan ke proses pembuatan invoice.</p>
                    </div>
                </div>

                <form action="<?php echo e(route('proses-penawaran')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="hide_barang" name="hide_barang">
                    <input type="hidden" id="hide_harga" name="hide_harga">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <label for="penawaran_deskripsi">Deskripsi Penawaran : </label>
                            <input type="text" name="penawaran_deskripsi" class="form-control" id="penawaran_deskripsi"
                                placeholder="Tuliskan deskripsi tentang pengadaan atau peminjaman barang anda...">
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end">
                            <button type="submit" class="btn btn-info" id="button_proses">
                                Proses Penawaran
                            </button>
                        </div>
                    </div>
                </form>

                <hr />

                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h5>
                            <b>
                                Pilih Barang
                            </b>
                        </h5>
                    </div>

                    <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                        <button type="button" class="badge badge-lg badge-primary mr-1">
                            <b>Total Harga :
                                <span id="badgeshargatotal">0</span>
                            </b>
                        </button>
                        <button type="button" class="badge badge-lg badge-primary">
                            <b>Total Pilihan :
                                <span id="counterbadges">0</span>
                            </b>
                        </button>
                    </div>

                </div>

                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Barang</th>
                                    <th>Kondisi</th>
                                    <th>Kode</th>
                                    <th>Jumlah Stok</th>
                                    <th>Nilai (Sewa)</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->barang_nama); ?></td>
                                        <?php switch($item->barang_kondisi):
                                            case ('BAIK'): ?>
                                                <td><span style="color:green;"><?php echo e($item->barang_kondisi); ?></span></td>
                                            <?php break; ?>

                                            <?php case ('RUSAK'): ?>
                                                <td><span style="color:red;"><?php echo e($item->barang_kondisi); ?></span></td>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                        <td><?php echo e($item->barang_kode); ?></td>
                                        <td class="text-center"><?php echo e($item->barang_stok); ?></td>
                                        <td class="text-center"><?php echo e($item->barang_nilai); ?></td>
                                        <td class="mx-auto btn-group">
                                            <button type="button" class="btn btn-sm btn-info"
                                                onclick="simpan_barang(<?php echo e($item->id); ?>,<?php echo e($item->barang_nilai); ?>)">PILIH</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        let array_barang = [];
        let harga_total = 0;
        let count_items = 0;
        var counterbadges = document.getElementById("counterbadges");
        var badgeshargatotal = document.getElementById("badgeshargatotal");

        function counterUp() {
            count_items++;
            counterbadges.innerHTML = count_items;
            // badgeshargatotal.innerHTML = harga_total;
            $('#hide_barang').val(array_barang);
            $('#hide_harga').val(harga_total);
            $('#badgeshargatotal').html(harga_total);
        }

        function simpan_barang(id_barang, harga_barang) {
            console.log("fungsi simpan barang");
            if (array_barang.length !== 0) {
                check_array = array_barang.indexOf(id_barang);
                if (check_array > -1) {
                    array_barang.splice(check_array, -1);
                } else {
                    counterUp();
                    harga_total += parseInt(harga_barang);
                    array_barang.push(id_barang)
                }
            } else {
                counterUp();
                harga_total += parseInt(harga_barang);
                array_barang.push(id_barang)
            }
            $('#hide_barang').val(array_barang);
            $('#hide_harga').val(harga_total);
            $('#badgeshargatotal').html(harga_total);
        }

        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-lab\resources\views/penawaran/buat-penawaran.blade.php ENDPATH**/ ?>