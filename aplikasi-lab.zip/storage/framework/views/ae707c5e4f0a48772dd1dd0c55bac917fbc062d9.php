<?php $__env->startSection('title', 'RuangLab'); ?>
<?php $__env->startSection('content-prefix', 'Daftar Barang'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Daftar Barang'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h4>
                            <b>
                                Daftar Barang
                            </b>
                        </h4>
                    </div>

                    <?php if($users->login_level == 'admin'): ?>
                        <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                            <button type="button" class="btn btn-sm btn-info d-flex justify-content-end" data-toggle="modal"
                                data-target="#modal_tambah">Tambah Barang</button>
                        </div>
                    <?php endif; ?>

                    <!-- Modal Tambah -->
                    <div class="modal fade" id="modal_tambah" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabelLogout">Peringatan Aksi!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <form action="<?php echo e(route('tambah-barang')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="container">

                                            <div class="form-row">
                                                
                                                <div class="form-group col-sm-6 col-md-6 col-lg-6">
                                                    <label for="barang_nama">Nama Barang </label>
                                                    <input type="text" class="form-control" id="barang_nama"
                                                        name="barang_nama" placeholder="Contoh : Djarum Coklat. ">
                                                </div>
                                                <div class="form-group col-sm-6 col-md-6 col-lg-6">
                                                    <label for="barang_status">Status Barang</label>
                                                    <select class="custom-select my-1 mr-sm-2"
                                                        id="inlineFormCustomSelectPref" name="barang_status">
                                                        <option value="BAIK" selected>Baik</option>
                                                        <option value="BARU">Baru</option>
                                                        <option value="RUSAK">Rusak</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-row">
                                                
                                                <div class="form-group col-sm-6 col-md-6 col-lg-6">
                                                    <label for="barang_jumlah">Jumlah Stok</label>
                                                    <input type="number" class="form-control" id="barang_jumlah"
                                                        name="barang_jumlah">
                                                </div>
                                                <div class="form-group col-sm-6 col-md-6 col-lg-6">
                                                    <label for="barang_harga">Nilai (Harga Sewa)</label>
                                                    <input type="number" class="form-control" id="barang_harga"
                                                        name="barang_harga">
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-danger"
                                            data-dismiss="modal">Batalkan</button>
                                        <button type="submit" class="btn btn-primary">Tambah Data</button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                    <!-- END Modal Tambah -->
                </div>

                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Barang</th>
                                    <th>Kondisi</th>
                                    <th>Kode</th>
                                    <th>Jumlah Stok</th>
                                    <th>Nilai (Sewa)</th>
                                    <?php if($users->login_level == 'admin'): ?>
                                        <th>Opsi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->barang_nama); ?></td>
                                        <td><?php echo e($item->barang_kondisi); ?></td>
                                        <td><?php echo e($item->barang_kode); ?></td>
                                        <td><?php echo e($item->barang_stok); ?></td>
                                        <td>
                                            <?php echo e('Rp ' . number_format($item->barang_nilai, 2, ',', '.')); ?>

                                        </td>
                                        <?php if($users->login_level == 'admin'): ?>
                                            <td class="mx-auto btn-group">
                                                
                                                <button type="button" class="btn btn-sm btn-info mr-1" data-toggle="modal"
                                                    data-target="#modal_ubah<?php echo e($item->id); ?>">Ubah</button>
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                                    data-target="#modal_hapus<?php echo e($item->id); ?>">Hapus</button>


                                                <!-- Modal Ubah -->
                                                <div class="modal fade" id="modal_ubah<?php echo e($item->id); ?>" tabindex="-1"
                                                    role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                    Peringatan Aksi!</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>

                                                            <form action="<?php echo e(route('ubah-barang', $item->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-body">

                                                                    <div class="container">

                                                                        <div class="form-row">
                                                                            
                                                                            <div
                                                                                class="form-group col-sm-6 col-md-6 col-lg-6">
                                                                                <label for="barang_nama">Nama Barang
                                                                                </label>
                                                                                <input type="text" class="form-control"
                                                                                    id="barang_nama" name="barang_nama"
                                                                                    value="<?php echo e($item->barang_nama); ?>">
                                                                            </div>
                                                                            <div
                                                                                class="form-group col-sm-6 col-md-6 col-lg-6">
                                                                                <label for="barang_status">Status
                                                                                    Barang</label>
                                                                                <select class="custom-select my-1 mr-sm-2"
                                                                                    id="inlineFormCustomSelectPref"
                                                                                    name="barang_status">
                                                                                    <option
                                                                                        value="<?php echo e($item->barang_kondisi); ?>"
                                                                                        selected>
                                                                                        <?php echo e($item->barang_kondisi); ?>

                                                                                    </option>
                                                                                    <option value="BAIK">Baik</option>
                                                                                    <option value="BARU">Baru</option>
                                                                                    <option value="RUSAK">Rusak</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-row">
                                                                            
                                                                            <div
                                                                                class="form-group col-sm-6 col-md-6 col-lg-6">
                                                                                <label for="barang_jumlah">Jumlah
                                                                                    Stok</label>
                                                                                <input type="number" class="form-control"
                                                                                    id="barang_jumlah"
                                                                                    name="barang_jumlah"
                                                                                    value="<?php echo e($item->barang_stok); ?>">
                                                                            </div>
                                                                            <div
                                                                                class="form-group col-sm-6 col-md-6 col-lg-6">
                                                                                <label for="barang_harga">Nilai (Harga
                                                                                    Sewa)</label>
                                                                                <input type="number" class="form-control"
                                                                                    id="barang_harga" name="barang_harga"
                                                                                    value="<?php echo e($item->barang_nilai); ?>">
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-outline-danger"
                                                                        data-dismiss="modal">Batalkan</button>
                                                                    <button type="submit" class="btn btn-primary">Ubah
                                                                        Data</button>
                                                                </div>

                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END Modal Ubah -->

                                                <!-- Modal Hapus -->
                                                <div class="modal fade" id="modal_hapus<?php echo e($item->id); ?>"
                                                    tabindex="-1" role="dialog"
                                                    aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabelLogout">
                                                                    Peringatan
                                                                    Aksi!</h5>
                                                                <button type="button" class="close"
                                                                    data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Apakah anda yakin ingin menghapus item ini?
                                                                    <br>
                                                                    Nama Barang : <b><?php echo e($item->barang_nama); ?></b>
                                                                </p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form action="<?php echo e(route('hapus-barang', $item->id)); ?>"
                                                                    method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="hapus_id"
                                                                        value="<?php echo e($item->id); ?>">
                                                                    <button type="button" class="btn btn-outline-danger"
                                                                        data-dismiss="modal">Batalkan</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Hapus</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-lab\resources\views/barang/daftar-barang.blade.php ENDPATH**/ ?>